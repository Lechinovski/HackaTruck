//
//  eSportsHubApp.swift
//  eSportsHub
//
//  Created by Student09 on 28/09/23.
//

import SwiftUI

@main
struct eSportsHubApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
